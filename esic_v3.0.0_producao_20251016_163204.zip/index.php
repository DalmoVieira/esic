<?php
// Redirecionar para a página de login
header("Location: login.php");
exit;
?>